NeonWave AI Asset Pack

Источник:
Оригинальная AI-сгенерированная иконка NeonWave, подготовленная без перерисовки дизайна.

Готовые assets:
- NeonWave_AI_1024.png — исходный мастер 1024x1024.
- NeonWave_48/72/96/108/144/192.png — готовые PNG.
- adaptive_foreground — прозрачный foreground, извлечённый из AI artwork.
- adaptive_background — navy background.
- monochrome — белый monochrome mask на прозрачности.
- android/res — структура ресурсов для Android.
- mipmap-anydpi-v26/ic_launcher.xml — adaptive icon с monochrome для Android 13+.

Важно:
PNG-файлы являются результатом подготовки AI-артворка, а не новой рисованной кодом иконкой.
