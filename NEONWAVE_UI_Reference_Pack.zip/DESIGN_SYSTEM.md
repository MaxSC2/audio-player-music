# NEONWAVE UI Reference Pack

Это визуальный пакет для Codex/ИИ-кодера. Референсы показывают направление, а не требуют буквального копирования.

## Design language
- Dark cinematic / futuristic / premium
- Almost-black base background
- Accent colors derived from current artwork
- Purple/blue/cyan as default accents, but dynamic per track
- Rounded surfaces, restrained glow, subtle borders
- 3D album carousel is a signature feature
- Persistent mini-player on library screens
- Consistent bottom navigation

## Product principle
Music is a space, not a list.

The player should feel like one coherent product across Now Playing, Tracks, Playlists, Albums, Artists, Search, Settings, context menus and detail screens.

## Important
Do not copy Spotify/Apple Music. Preserve NEONWAVE identity.
Do not sacrifice readability for glow.
Do not make every element neon.
Performance on mid-range Android is more important than expensive blur/shaders.
