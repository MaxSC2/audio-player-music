# Codex prompt: Now Playing

Use `screens/01_now_playing.png` as the primary visual reference.

Redesign the existing Flutter Now Playing screen around the existing 3D album carousel. Preserve audio logic. Make the central cover the dominant object, side covers smaller and rotated in perspective. Add artwork-derived ambient lighting, subtle waveform, compact premium controls, progress, track metadata, favorite and overflow actions. Keep the UI dark and cinematic.

Interaction requirements:
- swipe left/right physically moves the carousel
- tap/drag progress
- play/pause controls remain thumb-friendly
- changing track smoothly morphs ambient colors
- pause reduces visualizer motion
- preserve current queue/audio state

Do not copy the reference pixel-for-pixel. Recreate its hierarchy and visual language using the project's existing architecture.
