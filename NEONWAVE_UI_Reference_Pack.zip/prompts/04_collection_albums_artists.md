# Codex prompt: Albums + Artists

Use `screens/04_collection_albums_artists.png` as visual reference.

Create a unified Collection surface with Albums and Artists modes. Albums use artwork-first grid cards with title, artist and track count. Artists use circular portraits/avatars with artist name and album count. Provide sorting/filtering and a clean way to switch between Albums and Artists.

Keep the visual language consistent with Now Playing and Library: dark surfaces, subtle dynamic accent, restrained glow, strong typography and persistent mini-player.
