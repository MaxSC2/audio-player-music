# Codex prompt: Tracks / Library

Use `screens/02_tracks_library.png` as visual reference.

Redesign the main Tracks library. Keep search, filter, tabs, track list, favorite, overflow menu and persistent mini-player. The list must be information-dense but calm. Use consistent album thumbnails, title/artist hierarchy, duration, active-track accent and subtle separators/borders.

The currently playing track should be visually connected to the mini-player and the main Now Playing theme.

Keep the existing data and functionality. Improve only UI/UX and component architecture where necessary.
