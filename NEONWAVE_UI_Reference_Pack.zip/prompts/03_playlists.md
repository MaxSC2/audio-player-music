# Codex prompt: Playlists

Use `screens/03_playlists.png` as visual reference.

Create a premium playlist browser: search, filter/sort, create playlist action, playlist cards with artwork, title, track count and play action. Use a 2-column responsive grid on suitable phones, but gracefully fall back to a single column when width is insufficient.

Keep persistent mini-player and bottom navigation consistent with Tracks.

Playlist cards should feel like the same NEONWAVE product, not generic Material cards.
