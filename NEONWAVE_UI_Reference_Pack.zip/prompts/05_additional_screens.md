# Codex prompt: Remaining NEONWAVE screens

Extend the same design system to every existing feature, not only the four reference screens.

Required screens/states:
1. Search results: tracks, albums, artists, playlists; clear empty/loading states.
2. Album detail: large artwork, title/artist, track count, play/shuffle, track list, mini-player.
3. Artist detail: portrait, name, albums, popular tracks, discography.
4. Playlist detail: artwork, title, controls, track list, reorder/edit states.
5. Folder browser.
6. Favorites.
7. History / recently played.
8. Categories / genres.
9. Track context menu / bottom sheet.
10. Queue.
11. Settings.
12. Theme selection.
13. Audio/visualizer settings.
14. Empty, error and permission states.

Every screen must reuse the same tokens, cards, typography, icons, mini-player, bottom navigation and dynamic accent system.
Do not invent unrelated visual styles for individual screens.
